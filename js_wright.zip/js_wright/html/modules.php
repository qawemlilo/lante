<?php
defined('_JEXEC') or die('Restricted access');

// Include default chromes
$app = JFactory::getApplication();
include(JPATH_THEMES.'/'.$app->getTemplate().'/'.'wright'.'/'.'html'.'/'.'modules.php');